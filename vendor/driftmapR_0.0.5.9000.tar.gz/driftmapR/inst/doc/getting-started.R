## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>", fig.width = 7, fig.height = 5)

## ----input--------------------------------------------------------------------
library(driftmapR)

first <- data.frame(
  entity = letters[1:6], time = 1,
  x = c(0, 3, 0, 3, 1, 2), y = c(0, 0, 2, 2, 1, 1)
)
true_second <- transform(first, time = 2)
true_second$x[true_second$entity == "e"] <- 1.4
true_second$y[true_second$entity == "f"] <- 1.2

# Rotate by 90 degrees and translate the second coordinate system.
second <- transform(true_second, x = -y + 7, y = x - 4)
object <- drift_data(rbind(first, second), periods = 1:2)
object
plot_drift_map(object, aligned = FALSE, trajectories = FALSE)

## ----alignment----------------------------------------------------------------
# In this synthetic example a:d are known stationary, non-collinear anchors.
aligned <- align_snapshots(object, reference = "previous",
                            scale = FALSE, anchors = letters[1:4])
aligned
aligned$transformations
plot_drift_map(aligned, labels = TRUE)

## ----movement-----------------------------------------------------------------
movement <- measure_drift(aligned)
movement
stopifnot(max(abs(movement$distance[movement$entity %in% letters[1:4]])) < 1e-9)
stopifnot(abs(movement$distance[movement$entity == "e"] - 0.4) < 1e-9)
stopifnot(abs(movement$distance[movement$entity == "f"] - 0.2) < 1e-9)

