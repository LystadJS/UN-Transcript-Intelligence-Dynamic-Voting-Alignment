## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>")

## ----example------------------------------------------------------------------
library(driftmapR)

first <- data.frame(
  entity = letters[1:8], time = 1,
  x = c(0, 1, 0, 1, 4, 5, 4, 5), y = rep(c(0, 0, 1, 1), 2),
  cluster = rep(c("A", "B"), each = 4)
)
second <- transform(first, time = 2, cluster = rep(c("Y", "X"), each = 4))
fit <- drift_data(rbind(first, second)) |> match_clusters()
fit$clusters
fit$diagnostics$cluster_matching$assignments
fit$diagnostics$cluster_matching$periods

# Labels change, but all eight entities retain their persistent identifiers.
members <- fit$clusters
before <- members[members$period_index == 1, ]
after <- members[members$period_index == 2, ]
stopifnot(identical(before$cluster_id,
                    after$cluster_id[match(before$entity, after$entity)]))

## ----stricter-----------------------------------------------------------------
strict <- drift_data(rbind(first, second)) |>
  match_clusters(min_overlap = 3L, min_jaccard = 0.75)
strict$diagnostics$cluster_matching$transitions

## ----ambiguity----------------------------------------------------------------
tie_first <- first[1:4, ]
tie_first$cluster <- c("A", "A", "B", "B")
tie_second <- transform(tie_first, time = 2, cluster = c("X", "Y", "X", "Y"))
tied <- drift_data(rbind(tie_first, tie_second)) |> match_clusters()
tied$diagnostics$cluster_matching$assignments
tied$diagnostics$cluster_matching$periods

## ----split--------------------------------------------------------------------
split_first <- transform(first, cluster = "A")
split_second <- transform(first, time = 2, cluster = c(rep("X", 6), rep("Y", 2)))
split_fit <- drift_data(rbind(split_first, split_second)) |> match_clusters()
split_fit$diagnostics$cluster_matching$transitions

