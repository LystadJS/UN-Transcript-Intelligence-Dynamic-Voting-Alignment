## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>")

## ----data---------------------------------------------------------------------
library(driftmapR)
set.seed(260914L)
entity <- sprintf("E%02d", 1:12)
positions <- cbind(seq(-2, 2, length.out = 12), rnorm(12))
features <- sprintf("f%02d", 1:8)
loadings <- lapply(1:4, function(i) diag(2) + matrix(rnorm(4, sd = 0.18), 2))
panel <- do.call(rbind, lapply(1:3, function(period) {
  latent <- positions
  latent[12, ] <- latent[12, ] + (period - 1) * c(0.35, -0.2)
  measured <- do.call(cbind, lapply(loadings, function(x) latent %*% x))
  colnames(measured) <- features
  data.frame(entity, time = period, measured, check.names = FALSE)
}))
design <- paired_unit_design(
  units = stats::setNames(rep(paste0("unit", 1:4), each = 2), features),
  assumptions = paste(
    "Simulated units have iid random loading matrices; dependence across",
    "columns, entities and periods remains within each unit. Results condition",
    "on these entities and their observed availability."
  )
)

## ----fit----------------------------------------------------------------------
fit <- embed_snapshots(panel, features = features) |>
  align_snapshots(anchors = entity[1:11])
result <- bootstrap_drift(fit, design, B = 20L, seed = 914L,
                          keep = "replicates")
result$bootstrap$summary[result$bootstrap$summary$entity == "E12", ]

## ----accounting---------------------------------------------------------------
result$bootstrap$attempts
stopifnot(nrow(result$bootstrap$attempts) == 20L,
          all(result$bootstrap$attempts$success))
# This local check also confirms that a bootstrap call preserves caller RNG.
set.seed(19L)
before <- .Random.seed
repeat_result <- bootstrap_drift(fit, design, B = 20L, seed = 914L,
                                 keep = "replicates")
stopifnot(identical(before, .Random.seed),
          identical(result$bootstrap$replicates,
                    repeat_result$bootstrap$replicates))

