## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>")

## ----feature-data-------------------------------------------------------------
library(driftmapR)
first <- data.frame(entity = letters[1:8], time = 1,
                    u = c(-2, -1, 0, 1, 2, 3, 1, -1),
                    v = c(0, 1, -1, 2, 0, 1, 3, -2))
second <- transform(first, time = 2)
second$u[second$entity == "h"] <- second$u[second$entity == "h"] + 0.6
second$v[second$entity == "h"] <- second$v[second$entity == "h"] - 0.8
panel <- rbind(first, second)
# An isometric loading into four dimensions makes the movement truth exact.
panel$f1 <- panel$u / sqrt(2)
panel$f2 <- panel$v / sqrt(2)
panel$f3 <- panel$u / sqrt(2)
panel$f4 <- panel$v / sqrt(2)
features <- paste0("f", 1:4)
input <- panel[c("entity", "time", features)]
raw <- embed_snapshots(input, features = features, method = "pca")
raw$diagnostics$embedding

## ----align--------------------------------------------------------------------
# These seven entities are known to be stable in this constructed example.
fit <- align_snapshots(raw, anchors = letters[1:7], scale = FALSE)
movement <- measure_drift(fit)
movement[c("entity", "time_from", "time_to", "distance")]
stopifnot(max(movement$distance[movement$entity != "h"]) < 1e-8,
          abs(movement$distance[movement$entity == "h"] - 1) < 1e-8)

## ----plot, fig.width=6, fig.height=4------------------------------------------
plot_drift_map(fit)

## ----preprocessing------------------------------------------------------------
standardized <- embed_snapshots(input, features, standardize = "first")
standardized$embedding_metadata$preprocessing$scales[[1]]

## ----weights------------------------------------------------------------------
weighted <- embed_snapshots(input, features, feature_weights = c(2, 1, 0, 1))
weighted$embedding_metadata$feature_weights

## ----cmds-features------------------------------------------------------------
mds_fit <- embed_snapshots(input, features, method = "cmds") |>
  align_snapshots(anchors = letters[1:7])
stopifnot(max(abs(measure_drift(mds_fit)$distance - movement$distance)) < 1e-8)
mds_fit$diagnostics$embedding

## ----cmds-distances-----------------------------------------------------------
distances <- lapply(1:2, function(period) {
  rows <- input[input$time == period, ]
  x <- as.matrix(rows[features])
  rownames(x) <- rows$entity
  stats::dist(x)
})
mds_from_distances <- embed_snapshots(distances, method = "cmds", periods = 1:2)
mds_from_distances$diagnostics$embedding

