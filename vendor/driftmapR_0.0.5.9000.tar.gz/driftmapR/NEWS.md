# driftmapR 0.0.5.9000

* Completed the first bounded joint displacement-vector calibration study:
  six prespecified scenarios, 80 independent datasets each, 199 bootstrap
  attempts per defined observed estimator, and 18 paired PCA/MDS audit cases.
* Added analytic population-embedding targets, fixed evaluation gauges, three
  experimental region constructions, and independent helper/accounting tests.
* Retained all outer failures and exactly 93,132 main bootstrap attempts;
  separated conditional coverage, delivery, operational yield, and selection.
* Found undercoverage in the whole-map null and other scenarios. Rare-axis
  rank failures and success gates altered unit/dataset composition. No candidate
  is promoted to calibrated inference; research helpers are not public exports.
* Public embedding, alignment, cluster, and bootstrap engine code is unchanged
  from 0.0.4.9000. Updated evidence and the development roadmap.

# driftmapR 0.0.4.9000

* Added `paired_unit_design()` and a serial `bootstrap_drift()` engine for
  declared exchangeable measurement units or equal-width blocks, with optional
  strata and identical sampled multiplicities across periods.
* Refits preprocessing/embeddings and temporal alignment; establishes every
  replicate's baseline in the observed frame without scaling.
* Added independent L'Ecuyer-CMRG streams and isolated draw planning that leaves
  caller RNG state, including cached Box-Muller normals, untouched.
* Attempts exactly B draws; preserves failed stages, periods, counts, messages,
  warnings, and available spectral/alignment diagnostics without retrying failures.
* Added conditional means, covariance, type-7 quantiles, Monte Carlo mean SEs,
  success gates, provenance, and optional raw replicate retention.
* Added independent draw/refit/summary tests and a reproducible paired-unit pilot.
* Original feature data with unit observed weights are required. General
  resamplers, cluster refitting/stability, and calibrated confidence regions
  remain unimplemented; sample quantiles are not inferential confidence limits.

# driftmapR 0.0.3.9000

* Added `embed_snapshots()` for centered PCA and classical MDS from repeated
  numeric features, and classical MDS from labeled dissimilarity snapshots.
* Retains original inputs, Gram spectra, fitted models, and preprocessing;
  reports retained inertia, truncation-boundary ties, and MDS reconstruction.
* Added common or period-specific standardization and explicit feature weights
  that reproduce column multiplicities without adding dependencies.
* Non-Euclidean dissimilarities error by default; explicit truncation warns and
  reports negative inertia. Rank-deficient two-dimensional maps are rejected.
* Added independent adapter/kernel tests, a reproducible high-dimensional
  simulation, and a runnable embedding vignette.
* Defined fixed-entity bootstrap targets, paired resampling units, common frames,
  failure accounting, and future calibration gates. The resampling engine and
  inferential intervals remain unimplemented.

# driftmapR 0.0.2.9000

* Added `match_clusters()` for one-to-one correspondence between supplied labels
  in adjacent snapshots, maximizing shared-entity overlap counts.
* Added deterministic lexicographic tie resolution and per-selected-link
  alternative-optimum objective margins using the established `clue` solver.
* Added stable IDs, unmatched reasons, noise/missing-label handling, candidate
  split/merge flow diagnostics, matrices, and per-period denominators.
* Thresholds apply before optimization; clusters with no shared evidence never
  inherit identities, and identifiers never revive across an absent period.
* Added independent exhaustive-oracle assignment tests, public API regressions,
  a reproducible cluster simulation, and a correspondence vignette.
* Original labels, alignment, and geometric movement remain unchanged by cluster
  matching. No bootstrap uncertainty or statistical split/merge model is implied.

# driftmapR 0.0.1.9000

* Initial executable development prototype for repeated user-supplied 2-D maps.
* Added a validated `driftmap` object with extensible data/results/settings slots.
* Added previous- and first-reference orthogonal Procrustes fitting using base-R
  SVD, including reflection, translation, optional scale, anchors, and entity churn.
* Added explicit fitted transformations, fit counts, residuals, and rank checks.
* Added adjacent-interval movement tables and entity/fixed anchor distances.
* Added descriptive ggplot2 maps and S3 print/summary/plot methods.
* Added invariant/known-truth unit tests, a reproducible three-period simulation,
  documentation, and a cross-platform CI configuration.
* No cluster correspondence or inferential uncertainty is implemented.
